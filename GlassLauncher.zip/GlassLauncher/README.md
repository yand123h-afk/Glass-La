# Glass Launcher
iOS 26 tarzı (Liquid Glass) Android launcher. Kotlin + Jetpack Compose.

## GitHub ile derleme
1. Yeni bir GitHub deposu oluştur, bu klasörün tüm içeriğini (gizli `.github` klasörü dahil) yükle.
2. Actions sekmesi > "Build APK" çalışır (veya "Run workflow").
3. Bittiğinde çalışmanın altındaki Artifacts bölümünden `GlassLauncher-debug-apk` dosyasını indir.
4. Zip'i aç, APK'yı telefona kur (bilinmeyen kaynaklara izin ver).
5. Ayarlar > Uygulamalar > Varsayılan uygulamalar > Ana ekran uygulaması > Glass Launcher.
